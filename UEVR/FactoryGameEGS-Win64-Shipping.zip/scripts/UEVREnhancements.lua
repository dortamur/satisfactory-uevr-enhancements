-- Profile version to match against UEVR Enhancements mod expected version
local uevr_profile_version = 'v1.2.0-1'

local log_functions = uevr.params.functions

local function vr_log(text)
    log_functions.log_info("[UEVREnhancements] " .. text )
end

vr_log("Initializing UEVREnhancements.lua "..uevr_profile_version)

UEVR_UObjectHook.activate()

local vr = uevr.params.vr
local api = uevr.api;
local uobjects = uevr.types.FUObjectArray.get()
local last_gamepad = {}
local vrcoordinator
local uevr_bridge
local last_world
local last_level
local aim_mode = 0 -- 2
local ui_interact_mode = nil -- false
local movement_mode = 0 -- -1
local roomscale_mode = false
local tick_countdown = 0
local aim_methods = {'Game', 'HMD', 'Right Hand', 'Left Hand'}
local button_labels = {'A', 'X', 'B', 'Y', 'LeftStick', 'RightStick', 'LeftGrip', 'RightGrip', 'Start', 'Back'}
local active_controller = nil

-- Capacitive touch actions (VR.hpp s_action_*_touch_*)
local TOUCH_ACTIONS = {
    "/actions/default/in/AButtonTouchLeft",
    "/actions/default/in/BButtonTouchLeft",
    "/actions/default/in/ThumbrestTouchLeft",
    "/actions/default/in/AButtonTouchRight",
    "/actions/default/in/BButtonTouchRight",
    "/actions/default/in/ThumbrestTouchRight",
}

-- Touch action tracking
local action_handles = {}
local touch_state = {}

local function aim_method_label(aim_mode)
  return tostring(aim_methods[(aim_mode or 0)+1])
end

local function update_aim_mode()
  -- Aim mode changed!! Update UEVR Input Aim mode
  aim_mode = uevr_bridge.AimMode
  vr.set_aim_method(aim_mode)
  vr_log('Aim Mode changed: '..tostring(aim_mode)..' => '..aim_method_label(aim_mode))
end

local function update_roomscale_mode()
  -- Roomscale mode changed!!
  roomscale_mode = uevr_bridge.RoomscaleMode
  vr_log('Roomscale Mode changed: '..tostring(roomscale_mode))

  vr.set_mod_value("VR_RoomscaleMovement",tostring(roomscale_mode))
end

local function update_movement_mode()
  -- Movement mode changed!!
  movement_mode = uevr_bridge.MovementMode
  vr_log('Movement Mode changed: '..tostring(movement_mode))

  -- uevr.params.vr:set_mod_value("VR_AimMethod","1")
  vr.set_mod_value("VR_MovementOrientation",movement_mode)
  -- uevr.params.vr.set_movement_orientation()
end

local function update_haptics_left()
  -- local vr = uevr.params.vr
  -- vr_log('Haptics Left Update!')
  local source_handle = vr.get_left_joystick_source()
  -- uevr_bridge.HapticsLeftPending = false
  local duration = uevr_bridge.haptics_left_duration
  local frequency = uevr_bridge.haptics_left_frequency
  local amplitude = uevr_bridge.haptics_left_amplitude
  vr_log('Haptics Left: '..tostring(duration)..', '..tostring(frequency)..', '..tostring(amplitude))
  vr.trigger_haptic_vibration(0.0, duration, frequency, amplitude, source_handle)
end

local function update_haptics_right()
  -- local vr = uevr.params.vr
  -- vr_log('Haptics Right Update!')
  local source_handle = vr.get_right_joystick_source()
  -- uevr_bridge.HapticsRightPending = false
  local duration = uevr_bridge.haptics_right_duration
  local frequency = uevr_bridge.haptics_right_frequency
  local amplitude = uevr_bridge.haptics_right_amplitude
  vr_log('Haptics Right: '..tostring(duration)..', '..tostring(frequency)..', '..tostring(amplitude))
  vr.trigger_haptic_vibration(0.0, duration, frequency, amplitude, source_handle)
end

local function recenter_view()
  -- local vr = uevr.params.vr
  local hmd_position = UEVR_Vector3f.new()
  local hmd_rotation = UEVR_Quaternionf.new()
  vr.get_pose(vr.get_hmd_index(), hmd_position, hmd_rotation)
  vr.set_standing_origin(hmd_position)
  vr.recenter_view()
  vr_log('Recenter View and Reset Origin done')
end

local function init_bridge()
  -- Get UEVR Bridge via GameInstanceModule UEVRBridge
  local game_instance_module_c = api:find_uobject('Class /Script/SML.GameInstanceModule')
  if game_instance_module_c == nil then
      vr_log("Class GameInstanceModule not found")
  else
    vr_log("GameInstanceModule Class: "..game_instance_module_c:get_full_name())
    local game_instance_modules = UEVR_UObjectHook.get_objects_by_class(game_instance_module_c, false)

    vr_log("GameInstanceModules: ")
    for i, module in ipairs(game_instance_modules) do
      vr_log(" - "..module:get_fname():to_string()..' / '..module:get_full_name())
      if (module:get_fname():to_string() == 'UEVREnhancements_UEVRBridge') then
        vr_log('Found UEVRBridge module as GameInstanceModule!')
        uevr_bridge = module
      end
    end
  end

  if uevr_bridge == nil then
    vr_log("UEVRBridge not found")
  else
    vr_log("UEVRBridge found!")
    local pv = uevr.params.version
    local fn = uevr.params.functions
    vr_log("UEVR API: "..tostring(pv)..' / '..tostring(pv.major)..'.'..tostring(pv.minor)..'.'..tostring(pv.patch))
    vr_log("UEVR Build: "..tostring(fn.get_build_date())..' / '..tostring(fn.get_commit_hash())..' / '..tostring(fn.get_branch()))
    vr_log("UEVRBridge: "..uevr_bridge:get_fname():to_string()..' / '..uevr_bridge:get_full_name())
    -- uevr_bridge:DebugLog('Test')
    uevr_bridge:InitUEVRBridge(uevr_profile_version, tostring(pv.major)..'.'..tostring(pv.minor)..'.'..tostring(pv.patch), tostring(fn.get_build_date()), tostring(fn.get_commit_hash()), tostring(fn.get_branch()))
    -- uevr_bridge.IsInitialised = true

    uevr_bridge.SetHapticsRightEffect:hook_ptr(nil, function(fn, obj, locals, result)
        update_haptics_right()
        vr_log('SetHapticsRightEffect: '..obj:get_fname():to_string() .. " called")
      end
    )

    uevr_bridge.SetHapticsLeftEffect:hook_ptr(nil, function(fn, obj, locals, result)
        update_haptics_left()
        vr_log('SetHapticsLeftEffect: '..obj:get_fname():to_string() .. " called")
      end
    )

    uevr_bridge.SetAimMode:hook_ptr(nil, function(fn, obj, locals, result)
        vr_log('SetAimMode called: '..tostring(uevr_bridge.AimMode)..' => '..aim_method_label(uevr_bridge.AimMode))
        if (uevr_bridge.AimMode ~= aim_mode) then
          -- Interaction/Vehicle mode changed! Update UEVR Input Aim mode
          update_aim_mode()
        end
      end
    )

    uevr_bridge.SetMovementMode:hook_ptr(nil, function(fn, obj, locals, result)
        -- vr_log('SetMovementMode called: '..tostring(aim_mode)..' '..tostring(uevr_bridge.AimMode))
        if (uevr_bridge.MovementMode ~= movement_mode) then
          -- Movement mode changed!
          update_movement_mode()
        end
      end
    )

    uevr_bridge.SetRoomscaleMode:hook_ptr(nil, function(fn, obj, locals, result)
        -- vr_log('SetRoomscaleMode called: '..tostring(aim_mode)..' '..tostring(uevr_bridge.AimMode))
        if (uevr_bridge.RoomscaleMode ~= roomscale_mode) then
          -- Roomscale mode changed!
          update_roomscale_mode()
        end
      end
    )

    uevr_bridge.RecenterView:hook_ptr(nil, function(fn, obj, locals, result)
        -- vr_log('RecenterView called')
        recenter_view()
      end
    )

    -- Check if SetUObjectHookDisabled can be hooked
    if (uevr_bridge.SetUObjectHookDisabled ~= nil) then
      uevr_bridge.SetUObjectHookDisabled:hook_ptr(nil, function(fn, obj, locals, result)
          vr_log('SetUObjectHookDisabled called: '..tostring(uevr_bridge.UObjectHookDisabled))
          -- Disable UObject Hook
          if (uevr_bridge.UObjectHookDisabled) then
            vr_log('Disabling UObject Hook')
            UEVR_UObjectHook.set_disabled(true)
          else
            -- vr_log('Enabling UObject Hook')
            vr_log('Reactivating UObject Hook')
            UEVR_UObjectHook.activate()
            UEVR_UObjectHook.set_disabled(false)
          end

        end
      )
    end

    -- Check if SetUEVRModValue can be hooked
    if (uevr_bridge.SetUEVRModValue ~= nil) then
      uevr_bridge.SetUEVRModValue:hook_ptr(nil, function(fn, obj, locals, result)
          vr_log("SetUEVRModValue: "..tostring(uevr_bridge.UEVRModPropName).."="..tostring(uevr_bridge.UEVRModPropValue))

          -- Set the UEVR property based on mod settings
          vr.set_mod_value(tostring(uevr_bridge.UEVRModPropName), tostring(uevr_bridge.UEVRModPropValue))
        end
      )
    end

    uevr_bridge.UpdateVRPlayerState:hook_ptr(nil, function(fn, obj, locals, result)
        if (uevr_bridge.AimMode ~= aim_mode) then
          -- Interaction/Vehicle mode changed! Update UEVR Input Aim mode
          update_aim_mode()
        end

        if (uevr_bridge.MovementMode ~= movement_mode) then
          -- Movement mode changed!
          update_movement_mode()
        end

        if (uevr_bridge.RoomscaleMode ~= roomscale_mode) then
          -- Roomscale mode changed!
          update_roomscale_mode()
        end

        if (uevr_bridge.UIInteractMode ~= ui_interact_mode) then
          --  UI Interaction mode changed - log for streaming stabilisation switch
          ui_interact_mode = uevr_bridge.UIInteractMode
          vr_log('UI Interact Change [UIInteract='..tostring(ui_interact_mode)..']')
        end

      end
    )

    -- Update Aim mode to initial state
    update_aim_mode()

    -- Update movement mode to initial state
    update_movement_mode()

    -- update roomscale mode to initial state
    update_roomscale_mode()
  end
end

uevr.sdk.callbacks.on_xinput_get_state(function(retval, user_index, state)
  -- if true then return end -- Breakpoint

  if uevr_bridge == nil then
    return
  end

-- vr_log(string.format("[XInput] idx=%d wButtons=0x%04X", user_index, state.Gamepad.wButtons))

  local gamepad = state.Gamepad

    -- Lock onto the first slot that ever reports input; ignore the rest.
  if active_controller == nil and gamepad.wButtons ~= 0 then
      active_controller = user_index
      vr_log("Locked controller to index " .. user_index)
  end

  if active_controller ~= nil and user_index ~= active_controller then
      return -- ignore controller
  end

  -- vr_log('Comparing '..gamepad.wButtons..' to '..last_gamepad.wButtons)
  -- Compare gamepad states to last_gamepad
  if gamepad.wButtons ~= last_gamepad.wButtons then
    local btn_a = gamepad.wButtons & XINPUT_GAMEPAD_A ~= 0
    local btn_x = gamepad.wButtons & XINPUT_GAMEPAD_B ~= 0
    local btn_b = gamepad.wButtons & XINPUT_GAMEPAD_X ~= 0
    local btn_y = gamepad.wButtons & XINPUT_GAMEPAD_Y ~= 0
    local btn_left_stick = gamepad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB ~= 0
    local btn_right_stick = gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_THUMB ~= 0
    local btn_left_grip = gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER ~= 0
    local btn_right_grip = gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER ~= 0
    local btn_start = gamepad.wButtons & XINPUT_GAMEPAD_START ~= 0
    local btn_back = gamepad.wButtons & XINPUT_GAMEPAD_BACK ~= 0
    -- vr_log('Buttons A='..tostring(btn_a)..' B='..tostring(btn_b)..' X='..tostring(btn_x)..' Y='..tostring(btn_y)..' LS='..tostring(btn_left_stick)..' LG='..tostring(btn_left_grip)..' RS='..tostring(btn_right_stick)..' RG='..tostring(btn_right_grip))
    if (gamepad.wButtons ~= 0) then
      local button_states = { btn_a, btn_x, btn_b, btn_y, btn_left_stick, btn_right_stick, btn_left_grip, btn_right_grip, btn_start, btn_back }
      -- Assemble string list of active buttons
      local active_buttons = {}
      for i, state in ipairs(button_states) do
          if state then
              table.insert(active_buttons, button_labels[i])
          end
      end
      vr_log(string.format('Buttons wButtons=0x%04X: %s', gamepad.wButtons, table.concat(active_buttons, ', ')))
    else
      vr_log('Buttons cleared')
    end
    last_gamepad.wButtons = gamepad.wButtons
    uevr_bridge:UpdateButtonState(btn_a, btn_b, btn_x, btn_y, btn_left_stick, btn_left_grip, btn_right_stick, btn_right_grip, btn_start)
  end
  if (gamepad.sThumbLX or 0) ~= last_gamepad.sThumbLX or (gamepad.sThumbLY or 0) ~= last_gamepad.sThumbLY then
    local stick_left_x = gamepad.sThumbLX or 0
    local stick_left_y = gamepad.sThumbLY or 0
    -- vr_log('Left Stick X='..tostring(stick_left_x)..' Y='..tostring(stick_left_y)) -- ..' UI='..tostring(user_index)..' RV='..tostring(retval)..' PN='..tostring(state.dwPacketNumber))
    last_gamepad.sThumbLX = gamepad.sThumbLX or 0
    last_gamepad.sThumbLY = gamepad.sThumbLY or 0
    uevr_bridge:UpdateLeftStickState(gamepad.sThumbLX, gamepad.sThumbLY)
  end
  if (gamepad.sThumbRX or 0) ~= last_gamepad.sThumbRX or (gamepad.sThumbRY or 0) ~= last_gamepad.sThumbRY then
    local stick_right_x = gamepad.sThumbRX or 0
    local stick_right_y = gamepad.sThumbRY or 0
    -- vr_log('Right Stick X='..tostring(stick_right_x)..' Y='..tostring(stick_right_y))
    last_gamepad.sThumbRX = gamepad.sThumbRX or 0
    last_gamepad.sThumbRY = gamepad.sThumbRY or 0
    uevr_bridge:UpdateRightStickState(gamepad.sThumbRX, gamepad.sThumbRY)
  end

  if gamepad.bLeftTrigger ~= last_gamepad.bLeftTrigger then
    local left_trigger = gamepad.bLeftTrigger
    -- vr_log('Left Trigger LT='..tostring(left_trigger))
    last_gamepad.bLeftTrigger = gamepad.bLeftTrigger
    uevr_bridge:UpdateLeftTriggerState(gamepad.bLeftTrigger ~= 0)
  end
  if gamepad.bRightTrigger ~= last_gamepad.bRightTrigger then
    local right_trigger = gamepad.bRightTrigger
    -- vr_log('Right Trigger RT='..tostring(right_trigger))
    last_gamepad.bRightTrigger = gamepad.bRightTrigger
    uevr_bridge:UpdateRightTriggerState(gamepad.bRightTrigger ~= 0)
  end

  -- vr_log('XState: '..tostring(user_index)..' / '..tostring(retval)..' / '..tostring(gamepad.wButtons)..' / '..tostring(left_trigger)..' / '..tostring(stick_left_x)..' / '..tostring(stick_left_y)..' / '..tostring(right_trigger)..' / '..tostring(stick_right_x)..' / '..tostring(stick_right_y))

  -- Check touch event status

  local controllers = {
      L = vr.get_left_joystick_source(),
      R = vr.get_right_joystick_source(),
  }

  for _, action_path in ipairs(TOUCH_ACTIONS) do
    local h = action_handles[action_path]
    if h ~= 0 then
        for hand, src in pairs(controllers) do
            local key = action_path .. hand
            local now = vr.is_action_active(h, src)
            if now ~= touch_state[key] then
                touch_state[key] = now
                vr_log(string.format("Touch: %-22s src=%s -> %s",
                    action_path:match("([^/]+)$"), hand, now and "TOUCH" or "release"))
            end
        end
    end
  end
end)

uevr.sdk.callbacks.on_post_engine_tick(function(engine, delta)

end)

uevr.sdk.callbacks.on_pre_engine_tick(function(engine, delta)
  if not vr.is_runtime_ready() then return end
  -- if true then return end -- Breakpoint

  -- Check every *n* ticks...
  tick_countdown = tick_countdown - 1
  if (tick_countdown <= 0) then
    tick_countdown = 500

    if (uevr_bridge == nil) then
      init_bridge()
      if (uevr_bridge == nil) then
        vr_log('UEVR Enhancement Mod not found! Did you install the mod?')
        return
      end
      -- Init touch event tracking
      for _, path in ipairs(TOUCH_ACTIONS) do
        action_handles[path] = vr.get_action_handle(path)
        if action_handles[path] == 0 then
            print("[TouchLog] NULL handle: " .. path)
        end
      end
    end

    -- vr_log('States: AM='..tostring(uevr_bridge.AimMode)..' UII='..tostring(uevr_bridge.UIInteractMode)..' MM='..tostring(uevr_bridge.MovementMode)..' RS='..tostring(uevr_bridge.RoomscaleMode))
  end

  -- Detect Touch events
  -- local L, R = vr.get_left_joystick_source(), vr.get_right_joystick_source()
  -- local h = {}
  -- local function act(p) h[p] = h[p] or vr.get_action_handle(p); return h[p] end
  -- local function down(p, src) return vr.is_action_active(act(p), src) end

  -- -- e.g. right thumbrest capacitive touch
  -- if down("/actions/default/in/ThumbrestTouchRight", R) then
  --   vr_log("Right Thumbrest Touched")
  -- end

end)
